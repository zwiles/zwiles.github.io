# [Start Bootstrap - Clean Blog](https://startbootstrap.com/template-overviews/clean-blog/)

## Copyright and License

Copyright 2013-2017 Blackrock Digital LLC. Code released under the [MIT](https://github.com/BlackrockDigital/startbootstrap-clean-blog/blob/gh-pages/LICENSE) license.
